const mongoose = require('mongoose');

const PetSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true }, // Add this
    mobile: { type: String, required: true },
    address: { type: String, required: true },
    service: { type: String },
    description: { type: String },
});

module.exports = mongoose.model('Pet', PetSchema);