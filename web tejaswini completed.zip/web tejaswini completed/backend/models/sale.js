const mongoose = require('mongoose');

const petSaleSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    mobile: { type: String, required: true },
    petType: { type: String, required: true },
    price: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('PetSale', petSaleSchema);