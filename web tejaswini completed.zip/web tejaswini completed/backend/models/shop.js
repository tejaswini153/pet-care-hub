const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    mobile: { type: String, required: true },
    address: { type: String, required: true },
    productName: { type: String, required: true },
    price: { type: String, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);