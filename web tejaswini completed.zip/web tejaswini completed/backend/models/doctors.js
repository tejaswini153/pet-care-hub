const mongoose = require('mongoose');

const expertSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    mobile: { type: String, required: true },
    doctorName: { type: String, required: true },
    appointmentDate: { type: String, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Expert', expertSchema);