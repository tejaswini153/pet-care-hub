const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    mobile: { type: String, required: true },
    address: { type: String, required: true },
    service: { type: String, required: true },
    date: { type: String, required: true },
    price: { type: String, required: true },
    description: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Service', serviceSchema);