const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();

// --- Middlewares ---
app.use(express.json());
app.use(cors());

// --- Database Connection ---
mongoose.connect("mongodb://127.0.0.1:27017/PawCare")
  .then(() => console.log("✅ MongoDB Connected Locally Successfully!"))
  .catch((err) => console.log("❌ Database Error:", err));

// --- Home Route ---
app.get('/', (req, res) => {
    res.send("PawCare Backend is Running Successfully!");
});

// --- Login Route: Sending Welcome Email to User ---
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'hankaretejaswini054@gmail.com', 
            pass: 'bana ixxi irqj ebla'      
        }
    });

    const mailOptions = {
        from: '"PawCare Team" <hankaretejaswini054@gmail.com>',
        to: email, 
        subject: 'Welcome to PawCare - Login Successful',
        text: `Hello,\n\nThank you for choosing PawCare! You have successfully logged into your account.\nYou can now start managing your pet's health and schedules.\n\nBest Regards,\nPawCare Team`
    };

    try {
        await transporter.sendMail(mailOptions);
        res.status(200).json({ message: "Login Successful! Welcome email sent to the user." });
    } catch (error) {
        console.error("Email Error:", error);
        res.status(500).json({ message: "Login was successful, but the welcome email failed to send." });
    }
});

// ==========================================================
// --- मोन्गोस स्कीमा आणि कलेक्शन्स फिक्स (FORCE COLLECTION NAMES) ---
// ==========================================================
const commonSchema = new mongoose.Schema({
    name: String, email: String, mobile: String, address: String,
    service: String, date: String, price: String, description: String,
    productName: String, quantity: String, petBreed: String, petAge: String
}, { strict: false });

const Pet = mongoose.models.Pet || mongoose.model('Pet', commonSchema, 'pets');
const Service = mongoose.models.Service || mongoose.model('Service', commonSchema, 'services');
const Shop = mongoose.models.Shop || mongoose.model('Shop', commonSchema, 'shops');
const Sale = mongoose.models.Sale || mongoose.model('Sale', commonSchema, 'sales');
const Doctors = mongoose.models.Doctors || mongoose.model('Doctors', commonSchema, 'doctors');


// ==========================================
// --- १. SERVICES (सर्व्हिस बुकिंग राऊट्स) ---
// ==========================================
app.post('/add-service', async (req, res) => {
    try {
        const newService = new Service(req.body);
        await newService.save();
        res.status(201).json({ message: "✅ Service Booking saved in services collection!" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.get('/get-services', async (req, res) => {
    try {
        const services = await Service.find();
        res.json(services);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 🌟 [नवीन जोडलेले] सर्व्हिस बुकिंग अपडेट करण्यासाठी राऊट
app.put('/update-service/:id', async (req, res) => {
    try {
        const updatedService = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedService) return res.status(404).json({ message: "Service booking not found" });
        res.json({ message: "✅ Service updated successfully!", data: updatedService });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 🌟 [नवीन जोडलेले] सर्व्हिस बुकिंग डिलीट करण्यासाठी राऊट
app.delete('/delete-service/:id', async (req, res) => {
    try {
        const deletedService = await Service.findByIdAndDelete(req.params.id);
        if (!deletedService) return res.status(404).json({ message: "Service booking not found" });
        res.json({ message: "🗑️ Service booking removed successfully!" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// ==========================================
// --- २. SHOP ORDERS (शॉप खरेदी राऊट्स) ---
// ==========================================
app.post('/add-order', async (req, res) => {
    try {
        const newOrder = new Shop(req.body);
        await newOrder.save();
        res.status(201).json({ message: "✅ Shop Order saved in shops collection!" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.get('/get-orders', async (req, res) => {
    try {
        const orders = await Shop.find();
        res.json(orders);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// ==========================================
// --- ३. PET SALES (पेट खरेदी/विक्री राऊट्स) ---
// ==========================================
app.post('/add-sale', async (req, res) => {
    try {
        const newSale = new Sale(req.body);
        await newSale.save();
        res.status(201).json({ message: "✅ Pet Sale details saved in sales collection!" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.get('/get-sales', async (req, res) => {
    try {
        const sales = await Sale.find();
        res.json(sales);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// ==========================================
// --- ४. DOCTORS (डॉक्टर अपॉइंटमेंट राऊट्स) ---
// ==========================================
app.post('/add-doctor-booking', async (req, res) => {
    try {
        const newBooking = new Doctors(req.body);
        await newBooking.save();
        res.status(201).json({ message: "✅ Doctor Appointment saved in doctors collection!" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.get('/get-doctor-bookings', async (req, res) => {
    try {
        const bookings = await Doctors.find();
        res.json(bookings);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// ==========================================
// --- ५. SHOP (नवीन प्रॉडक्ट खरेदी राऊट्स) ---
// ==========================================
app.post('/add-shop-order', async (req, res) => {
    try {
        const newOrder = new Shop(req.body); 
        await newOrder.save();
        res.status(201).json({ message: "✅ Shop ऑर्डर यशस्वीरित्या 'shops' मध्ये सेव्ह झाली!" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.get('/get-shop-orders', async (req, res) => {
    try {
        const orders = await Shop.find();
        res.json(orders);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// ==========================================
// --- ६. ORIGINAL PET ROUTES (अपॉइंटमेंट अपडेट आणि डिलीटसह फिक्स) ---
// ==========================================
app.post('/add-pet', async (req, res) => {
    try {
        const newPet = new Pet(req.body);
        await newPet.save();
        res.status(201).json({ message: "✅ Information stored in pets collection!" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.get('/get-pets', async (req, res) => {
    try {
        const pets = await Pet.find();
        res.json(pets);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/update-pet/:id', async (req, res) => {
    try {
        const updatedPet = await Pet.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedPet) return res.status(404).json({ message: "Record not found" });
        res.json({ message: "✅ Record updated successfully!", data: updatedPet });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/delete-pet/:id', async (req, res) => {
    try {
        const deletedPet = await Pet.findByIdAndDelete(req.params.id);
        if (!deletedPet) return res.status(404).json({ message: "Record not found" });
        res.json({ message: "🗑️ Record removed successfully!" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


// --- Server Startup ---
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server started on http://localhost:${PORT}`);
});